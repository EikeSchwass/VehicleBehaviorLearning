namespace VehicleBehaviorLearning.Engine.Vehicles
{
    internal enum UserData
    {
        Wall,
        Wheel,
        ProgressSensor,
        Vehicle
    }
}