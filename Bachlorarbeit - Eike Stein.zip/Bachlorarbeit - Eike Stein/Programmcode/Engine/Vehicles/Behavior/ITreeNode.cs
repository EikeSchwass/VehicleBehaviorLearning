﻿namespace VehicleBehaviorLearning.Engine.Vehicles.Behavior
{
    public interface ITreeNode
    {
        ITreeNode ParentNode { get; }
    }
}