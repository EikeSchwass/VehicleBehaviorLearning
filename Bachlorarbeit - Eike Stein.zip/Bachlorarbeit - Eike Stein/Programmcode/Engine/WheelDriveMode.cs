namespace VehicleBehaviorLearning.Engine
{
    public enum WheelDriveMode
    {
        FrontWheelDrive,
        RearWheelDrive,
        AllWheelDrive
    }
}