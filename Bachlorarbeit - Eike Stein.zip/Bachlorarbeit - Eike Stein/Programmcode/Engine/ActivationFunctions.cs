namespace VehicleBehaviorLearning.Engine
{
    public enum ActivationFunctions
    {
        Sigmoid,
        TanH,
        Linear
    }
}