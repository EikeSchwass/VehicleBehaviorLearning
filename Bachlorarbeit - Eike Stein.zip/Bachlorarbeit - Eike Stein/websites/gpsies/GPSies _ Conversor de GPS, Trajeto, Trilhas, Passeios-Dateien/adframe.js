/**
 * AdBlock Detector v1.0
 * 30. Mar. 2013
 * unterhaltungsbox.com
 *
 *  Additional lines 
 *     to prevent 
 *     unblocking
 */

var advertisement = true;
