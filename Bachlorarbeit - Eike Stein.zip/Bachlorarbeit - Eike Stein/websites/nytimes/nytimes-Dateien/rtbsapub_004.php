window.advBidxc.rubiconresp({
"782647924" : {bl:[{bidder_id: 29, ext_placement_code: "biz-desk", no_bid: true, logging_pixels: [], og_bid: 0.0, fb: false, publisher_id: "8CU2553YN", nbc: 0, at: "O", mnet_id: "782647924", size: "728x90"}]}})
